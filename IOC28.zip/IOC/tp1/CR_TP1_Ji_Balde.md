---
title: TP1 - Compte rendu

---

#### Ji Stéphane
#### Balde Ibrahima
 

# TP1 - Compte rendu

## 2 Hello World ! RaspberryPi

1.Pourquoi passer par la redirection des ports ? 
    
    La redirection des ports permet la compilation et l'accès aux cartes à distances.
    
2.Pourquoi faut-il que vos fichiers soit dans un répertoire propre sur une RaspberryPi ? 

    Car sur la carte, on est plusieurs utilisateurs, on évite d'écraser les fichiers des autres. 


## 3. Configuration des clés ssh
    
#### Remarque
    On a appris qu'afin de ne pas de rentrer le mot de passe à chaque connexion ssh à la carte,  on ecrit les commandes suivantes:
    
    ssh-keygen -t rsa
    ssh-copy-id -i $HOME/.ssh/id_rsa.pub -p 622x pi@peri
    ssh -p 622x pi@peri
    
## 4. Prise en mains des outils de développement: Hello World! 
    
    
## 5. Contrôle de GPIO en sortie 

#### Problemes: 
    
    Le programme compilait mais l'executable n'etait pas dans le repertoire de la carte 
    solution : nom de la commande : make all copy 
    On pense que "make" n'appelait pas copy et %.x

#### Questions sur le code de blink0.c 
   1. Expliquez pourquoi, il pourrait être dangereux de se tromper de broche pour la configuration des GPIO.
   
    réponse : chaque broche est liée à des fonctions spécifiques. De ce fait, si on se trompe de broche, alors, on n'a pas le comportement souhaité.

   
   2. A quoi correspond l'adresse BCM2835_GPIO_BASE ?
        
    réponse : BCM2835_GPIO_BASE est l'adresse physique des GPIO
    
    
   3. Que représente la structure struct gpio_s ?
    
    reponse : C'est une une structure de données décrivant la carte des             registres :
        struct gpio_s {
                uint32_t gpfsel[7];
                uint32_t gpset[3];
                uint32_t gpclr[3];
                uint32_t gplev[3];
                uint32_t gpeds[3];
                uint32_t gpren[3];
                uint32_t gpfen[3];
                uint32_t gphen[3];
                uint32_t gplen[3];
                uint32_t gparen[3];
                uint32_t gpafen[3];
                uint32_t gppud[1];
                uint32_t gppudclk[3];
                uint32_t test[1];
                };
                

4. Dans quel espace d'adressage est l'adresse gpio_regs_virt ? 
    
        reponse : Il se situe dans l'espace adressage kernel

5. Dans la fonction gpio_fsel(), que contient la variable reg ?
    
        la variable reg contient la fonction précise à modifier ou non? 
        
6. Dans la fonction gpio_write(), pourquoi écrire à deux adresses différentes en fonction de la valeur val ?

        set = 1 -> allumer 
        clr = 1 -> éteindre
        Dans un premier temps, je me suis demandé "Pourquoi ne pas mettre les deux états sur un même registre"? 
        la réponse : le tableau de droit d'écriture est le même pour tout les GPIOs. Pour éviter une concurrence entre 2 Threads pour chacun 1 GPIO. 
        Une autre question " Pourquoi ne pas utiliser les opérations logiques |= et &=~?"  réponse : ceux ne sont pas des instructions atomique. 
        
7. Dans la fonction gpio_mmap(), à quoi correspond les flags de open()?

        Les flags:
        O_RDWR = autorisation de droit de lecture et d'écriture
        O_SYNC = synchronisation lors des écritures en registre
        
8. Dans la fonction gpio_mmap(), commentez les arguments de mmap().

        la fonction mmap = traduction de l'adresse virtuelle vers l'adresse physique. 
        la fonction mmap() prend en argument dans gpio_mmap(): 
        void *mmap(void *addr, size_t len, int prot, int flags, int fildes, off_t off);
        RPI_BLOCK_SIZE pour la taille
        PROT_READ | PROT_WRITE -> pour PROT (voir PROT)
        MAP_SHARED -> flag
        mmap_fd -> fichier de la structure physique des GPIOs
        BCM2835_GPIO_BASE -> adresse physique des GPIOs 

9. Que fait la fonction delay()?

        La fonction delay() prendre en argument un entier. L'argument est la valeur du temps de sleep en milisecondes.
    
10. Pourquoi doit-on utiliser sudo ?

        En utilisant sudo, nous avons accès au adresses kernel. 
        
        
### 7. Lecture de la valeur d'une entrée GPIO
    affichage de read_bp.c 
    etat de la broche 18 : 262144 
    etat de la broche 18 : 262144 
    etat de la broche 18 : 262144 
    etat de la broche 18 : 262144 





### Définitions 
    Cross-Compilation : compiler depuis l'ordinateur un programme destiné à un ordinateur B 
### Source
    https://raspberrytips.fr
