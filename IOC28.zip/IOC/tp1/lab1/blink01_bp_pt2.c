#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <pthread.h>

//------------------------------------------------------------------------------
// CONFIGURATION ET ADRESSES
//------------------------------------------------------------------------------
#define BCM2835_PERIPH_BASE     0x20000000
#define BCM2835_GPIO_BASE       ( BCM2835_PERIPH_BASE + 0x200000 )

#define GPIO_LED0   4
#define GPIO_LED1   17
#define GPIO_BP     18

#define GPIO_FSEL_INPUT  0
#define GPIO_FSEL_OUTPUT 1

// Variables globales pour les événements (Lignes d'interruption logiques)
int BP_ON = 0;   // Mis à 1 par le thread BP lors d'un appui
int BP_OFF = 0;  // Mis à 1 par le thread BP lors d'un relâchement

// Structure des registres GPIO
struct gpio_s {
    uint32_t gpfsel[7];
    uint32_t gpset[3];
    uint32_t gpclr[3];
    uint32_t gplev[3];
    // ... (les autres registres ne sont pas utilisés ici)
};

struct gpio_s *gpio_regs_virt;

//------------------------------------------------------------------------------
// FONCTIONS BAS NIVEAU
//------------------------------------------------------------------------------
static void gpio_fsel(uint32_t pin, uint32_t fun) {
    uint32_t reg = pin / 10;
    uint32_t bit = (pin % 10) * 3;
    uint32_t mask = 0b111 << bit;
    gpio_regs_virt->gpfsel[reg] = (gpio_regs_virt->gpfsel[reg] & ~mask) | ((fun << bit) & mask);
}

static void gpio_write(uint32_t pin, uint32_t val) {
    uint32_t reg = pin / 32;
    uint32_t bit = pin % 32;
    if (val == 1) gpio_regs_virt->gpset[reg] = (1 << bit);
    else gpio_regs_virt->gpclr[reg] = (1 << bit);
}

static int gpio_read(uint32_t pin) {
    uint32_t reg = pin / 32;
    uint32_t bit = pin % 32;
    return (gpio_regs_virt->gplev[reg] & (1 << bit)) != 0;
}

void delay(unsigned int milisec) {
    struct timespec ts;
    ts.tv_sec  = milisec / 1000;
    ts.tv_nsec = (milisec % 1000) * 1000000;
    nanosleep(&ts, NULL);
}

//------------------------------------------------------------------------------
// THREADS
//------------------------------------------------------------------------------

// Thread de détection du bouton (Gestion des événements)
void *thread_detect_bp(void *arg) {
    int val_prec = 1; // État de repos (bouton relâché = 1)
    int val_nouv;

    gpio_fsel(GPIO_BP, GPIO_FSEL_INPUT);

    while(1) {
        delay(20); // Lecture toutes les 20ms
        val_nouv = gpio_read(GPIO_BP);

        if (val_nouv != val_prec) { // Changement d'état détecté
            if (val_nouv == 0) {
                BP_ON = 1;  // Événement Appui
            } else {
                BP_OFF = 1; // Événement Relâchement
            }
            val_prec = val_nouv;
        }
    }
    return NULL;
}

// Thread LED0 : Mode télérupteur (Réagit à BP_ON)
void *thread_led0_teleruptor(void *arg) {
    int led_state = 0;
    gpio_fsel(GPIO_LED0, GPIO_FSEL_OUTPUT);
    gpio_write(GPIO_LED0, led_state);

    while(1) {
        if (BP_ON) {
            BP_ON = 0; // Acquittement de l'événement
            led_state = 1 - led_state; // Toggle
            gpio_write(GPIO_LED0, led_state);
            printf("Appui détecté : LED0 -> %d\n", led_state);
        }
        delay(10); // Petit délai pour ne pas saturer le CPU
    }
    return NULL;
}

// Thread LED1 : Clignotement périodique indépendant
void *thread_led1_blink(void *arg) {
    int val = 0;
    gpio_fsel(GPIO_LED1, GPIO_FSEL_OUTPUT);
    while(1) {
        gpio_write(GPIO_LED1, val);
        delay(500); // Clignote toutes les 500ms
        val = 1 - val;
    }
    return NULL;
}

//------------------------------------------------------------------------------
// MAIN
//------------------------------------------------------------------------------

#define RPI_BLOCK_SIZE 4096
static int mmap_fd;

static int gpio_mmap(void **ptr) {
    mmap_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mmap_fd < 0) return -1;
    void *res = mmap(NULL, RPI_BLOCK_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, mmap_fd, BCM2835_GPIO_BASE);
    if (res == MAP_FAILED) return -1;
    *ptr = res;
    return 0;
}

int main(int argc, char **argv) {
    pthread_t t_bp, t_led0, t_led1;

    if (gpio_mmap((void **)&gpio_regs_virt) < 0) {
        perror("-- Erreur mmap (lancez avec sudo)");
        exit(1);
    }

    printf("-- Système prêt. LED1 clignote, LED0 attend le bouton.\n");

    pthread_create(&t_bp,   NULL, thread_detect_bp, NULL);
    pthread_create(&t_led0, NULL, thread_led0_teleruptor, NULL);
    pthread_create(&t_led1, NULL, thread_led1_blink, NULL);

    pthread_join(t_bp, NULL);
    pthread_join(t_led0, NULL);
    pthread_join(t_led1, NULL);

    return 0;
}