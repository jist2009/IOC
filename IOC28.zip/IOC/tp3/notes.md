# TP3 : Pilotage d'un écran LCD en mode utilisateu et par un driver


# Ressources
ok , un document obsolète 

adress mémmoire LCD 

# 1 Configuration des GPIO pour le pilotage de l'écran

LCD , signaux de controles et de données, 
3 signaux de controles : RS, RW , E 
signaux de donnée : 4 ou 8

RW tjs connecté 
RS : 1 pour envoie donnée , 0 envoie commande 
E : validation 

### Comment faut-il configurer les GPIOs pour les différents signaux de l'afficher LCD ?
première idée , pourquoi on ne peut pas poser tous les signaux à la suite en commancant par zero ?
    - GPIO 0 et 1 sont systèmes
    - ok, Le GPIO 0 est en haut à gauche de la carte.Le GPIO 1 est en bas à droite.Le GPIO 2 est au milieu. donc croisement filaire

    1. Eviter les GPIO interdits au démarrage
    2. Séparer les signaux de controle et de données
    3. schéma de confi

### Comment écrire des valeurs vers le LCD ?
    écrire grace a ioctl,
    my_ioctl_function
    _IOW(type, num , taille)

### Quelles valeurs doivent être envoyées vers l'afficheur pour réaliser l'initialisation ?
    depuis le cpu pour vouloir envoyer un ordre d'affichage à l'afficheur.
    busy flag (BF) pour 10 mso


### Comment demander l'affichage d'un caractère ?
### Comment envoyer des commandes telles que : l'effacement de l'écran, le  déplacement du curseur, ### etc. ? 

# Question de moi : 
un GPIO ne peut avoir qu'un signal ? 
--> peut être relié à plusieurs signaux , mais n'active qu'un à la fois 




j'ai appris que C89 qu'on utilise, on ne pouvait pas initialiser les variables dans la boucle for 
Il faut initialiser avant la boucle for
sinon on doit utiliser la norme C99