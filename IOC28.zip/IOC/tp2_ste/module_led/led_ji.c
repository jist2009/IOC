/*#include <linux/module.h>
#include <linux/fs.h>

MODULE_LICENSE("GPL");
static int major;



static int 
open_led_ji(struct inode *inode, struct file *file) {
    printk(KERN_DEBUG "open()\n");
    return 0;
}

static ssize_t 
read_led_ji(struct file *file, char *buf, size_t count, loff_t *ppos) {
    printk(KERN_DEBUG "read()\n");
    return count;
}

static ssize_t 
write_led_ji(struct file *file, const char *buf, size_t count, loff_t *ppos) {
    printk(KERN_DEBUG "__ji_write()\n");
    return count;
}

static int 
release_led_ji(struct inode *inode, struct file *file) {
    printk(KERN_DEBUG "__ji_close()\n");
    return 0;
}

struct file_operations fops_led =
{
    .open       = open_led_ji,
    .read       = read_led_ji,
    .write      = write_led_ji,
    .release    = release_led_ji 
};

// 3. Fonctions INIT et EXIT (C'est ICI qu'on gère le Major)
static int __init mon_module_init(void)
{
    major = register_chrdev(0, "led_ji", &fops_led); 
    if (major < 0) {
        printk(KERN_ALERT "Erreur d'enregistrement du major\n");
        return major;
    }
    printk(KERN_DEBUG "Module LED JI chargé avec Major = %d\n", major);
    return 0;
}

static void __exit mon_module_cleanup(void)
{
    unregister_chrdev(major, "led_ji");
    printk(KERN_DEBUG "Module LED JI déchargé\n");
}

module_init(mon_module_init);
module_exit(mon_module_cleanup);
*/


#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include <asm/io.h>
#include <mach/platform.h>

MODULE_LICENSE("GPL");

// Configuration matérielle (à adapter selon votre câblage)
static int LED0 = 17;
//static int LED1 = 4;
static int BP = 18;
static int major;

// Définition de la structure des registres GPIO
struct gpio_s {
    uint32_t gpfsel[7];
    uint32_t gpset[3];
    uint32_t gpclr[3];
    uint32_t gplev[3];
    // ... (le reste de votre structure)
} volatile *gpio_regs = (struct gpio_s *)__io_address(GPIO_BASE);

// Fonctions utilitaires GPIO
static void gpio_fsel(int pin, int fun) {
    uint32_t reg = pin / 10;
    uint32_t bit = (pin % 10) * 3;
    uint32_t mask = 0b111 << bit;
    gpio_regs->gpfsel[reg] = (gpio_regs->gpfsel[reg] & ~mask) | ((fun << bit) & mask);
}

static void gpio_write(int pin, bool val) {
    if (!val) gpio_regs->gpset[pin / 32] = (1 << (pin % 32));
    else gpio_regs->gpclr[pin / 32] = (1 << (pin % 32));
}

static int gpio_read(int pin) {
    return (gpio_regs->gplev[pin / 32] >> (pin % 32)) & 1;
}

// Opérations du fichier
static int open_ledbp(struct inode *inode, struct file *file) {
    gpio_fsel(LED0, 1); // 1 = Output pour la LED
    gpio_fsel(BP, 0);   // 0 = Input pour le bouton
    return 0;
}

static ssize_t write_ledbp(struct file *file, const char *buf, size_t count, loff_t *ppos) {
    char kbuf;
    if (copy_from_user(&kbuf, buf, 1)) return -EFAULT;
    
    if (kbuf == '1') gpio_write(LED0, true);
    else if (kbuf == '0') gpio_write(LED0, false);
    
    return count;
}

static ssize_t read_ledbp(struct file *file, char *buf, size_t count, loff_t *ppos) {
    char val = gpio_read(BP) ? '1' : '0';
    if (copy_to_user(buf, &val, 1)) return -EFAULT;
    return 1; // On a lu 1 octet
}

static struct file_operations fops = {
    .open = open_ledbp,
    .read = read_ledbp,
    .write = write_ledbp,
};

static int __init mon_init(void) {
    major = register_chrdev(0, "led_ji", &fops);
    return 0;
}

static void __exit mon_exit(void) {
    unregister_chrdev(major, "led_ji");
}

module_init(mon_init);
module_exit(mon_exit);
