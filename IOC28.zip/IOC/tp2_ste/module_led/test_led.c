#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd = open("/dev/led_ji", O_RDWR);
    char etat_bp;
    
    if (fd < 0) { perror("Erreur open"); return 1; }

    printf("Lecture du bouton... Appuyez pour arrêter.\n");
    while(1) {
        read(fd, &etat_bp, 1);
        if (etat_bp == '0') {
            printf("Bouton pressé ! Allumage LED.\n");
            write(fd, "1", 1);
        } else {
            write(fd, "0", 1);
        }
        usleep(200000); // 100ms
    }
    close(fd);
    return 0;
}