# Pilote de périphérique 

# Driver pour les LEDs et le bouton poussoir 

# étape 1 : création et test d'un module noyau
 
### Quelle fonction est exécutée lorsqu'on insère le module du noyau ? 
    Dans le code, l'instruction module_init(mon_module_init); enregistre cette fonction comme point d'entrée. Elle utilise la macro __init pour indiquer au noyau qu'il s'agit d'une routine d'initialisation. C'est ici que s'affichera le message "Hello World <votre nom> !" dans les logs du noyau (accessibles via la commande dmesg



### Quelle fonction est exécutée lorsqu'on enlève le module du noyau ? 


# Compilation du code 


# étape 2 : ajout des paramètres au module 

# étape 3 : création d'un driver qui ne fait rien, mais qui le fait dans le noyau 

major : 
241 led_ji

###  Comment savoir que le device a été créé ? 
cat /proc/devices | grep led_ji
Si la ligne apparaît, le code est bien chargé et le noyau reconnaît votre driver.

ls -l /dev/led0_ji
Le fichier existe et les programmes utilisateurs (comme echo ou test.c) peuvent maintenant 'ouvrir.


# étape 4 : accès aux GPIO depuis les fonctions du pilote 
