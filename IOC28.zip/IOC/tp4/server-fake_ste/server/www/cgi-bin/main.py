#!/usr/bin/env python

html="""
<head>
  <title>Peri W213eb Server10</title>
</head>
<body>
LEDS:<br/>
<form method="POST" action="led.py">
  <input name="val" cols="20"></input>
  <input type="submit" value="Entrer">
</form>
</body>
"""
print("Content-Type: text/html\n")
print(html)
