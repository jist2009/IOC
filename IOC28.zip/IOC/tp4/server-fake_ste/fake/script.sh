#! /bin/bash

/users/enseig/franck/E-IOC/arm-bcm2708hardfp-linux-gnueabi/bin/bcm2708hardfp-gcc -Wall -o ledbp.x  ledbp.c

scp -P 62221 ledbp.x pi@peri:ji/tp4/server-fake_ste/fake/