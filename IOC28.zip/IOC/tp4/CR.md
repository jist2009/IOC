# Serveur WEB minimaliste

## 1. Communication par FIFO

### writer.py

#### Dans quel répertoire est créée la fifo ?
        La fifo est créée dans le répertoire /tmp 

#### Quelle différence mkfifo et open ?
        mkfifo est une fonction permettant de crée une FIFO nommée avec des modes d'exécution en paramètre et un chemin.
        Open() ne crée pas de FIFO,mais permet d'ouvrir les extrémités de la fifo pour permettre les lecture et les écritures

#### Pourquoi tester que la fifo existe ?
        Si la FIFO existe déja, il n'y a pas besoin dela crée.

#### À quoi sert flush ?
        flush() permet d'éffacer les écriture dans le buffer et de transferer les données vers la fifo.

#### Pourquoi ne ferme-t-on pas la fifo ?
       On devrait fermer la fifo.Mais peut etre qu'on ne laa ferme pas car il y'a toujours une transaction en cours.3


### reader.py

#### Que fait readline ? 
        readline() lit une ligne d'un fichier 

#### Expliquez le phénomène (... c'est le open(), mais pourquoi ? ...) 
        

## 2. Création d'un serveur fake


### Source
    openclassrooms.com
    learn.microsoft.com
    expertpython.fr
    