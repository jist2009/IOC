# Pilotes de périphériques 

## Objectifs 
comamnder les LEDS et le bouton poussoir par des pilotes 

## Création pilote pour LED et BP 

D'abord, qu'est ce que c'est un pilote? 
source : CM3
information : C'est le code des commandes
pilote accessible -> /dev/led0_

### On a besoin de créer test.c

Pour les LEDS

    -Le driver LED ne commande qu'une seule LED dont il reçoit le numéro au moment de l'enregistrement.
    
    -On éteint la led si on écrit '0', on l'allume en écrivant '1'.
    
    -Si le device led est accessible par /dev/led0_XY
    
        char led = '0';
        int fd = open("/dev/led0_XY", O_WR);
        write( fd, &led, 1);

Pour le bouton

    -Le driver BP contrôle l'unique bouton dont il reçoit le numéro au moment de l'enregistrement.

    -Quand le bouton est relâché, le pilote met le caractère '0'.
    
    -Quand le bouton est enfoncé, le pilote met une valeur différente de '0'.
    
    -Si le device bp est accessible par /dev/bp_XY

        char bp;
        int fd = open("/dev/bp_XY", O_RD);
        read( fd, &bp, 1);


## Etape 1 : création et test d'un module noyau 

### Q1 : Quelle fonction est exécutée lorsqu'on insère le module du noyau? 

    On appel la fonction "mon_module_init", lors du chargement du module mon_module, il dit "Hello wolrd <votre nom> !\n"

### Q2 : Quelle fonction est exécutée lorsqu'on enlève le module du noyau ? 

    On appel la fonction "mon_module_cleanup",  lorsqu'on enlève le module du noyau.
 

la fonction "printk()" est une fonction du kernel. Le kernel écrit sur un fichier 
/var/log/kern.log ou /var/log/syslog

### Compilation du module 

    sudo insmod ./module.ko
    lsmod 

    Module                  Size  Used by
    module                   797  0 
    snd_bcm2835            21342  0 
    snd_pcm                93100  1 snd_bcm2835
    snd_seq                61097  0 
    snd_seq_device          7209  1 snd_seq
    snd_timer              23007  2 snd_pcm,snd_seq
    snd                    67211  5 snd_bcm2835,snd_timer,snd_pcm,snd_seq,snd_seq_device
    i2c_bcm2708             6200  0 
    spi_bcm2708             6018  0 
    uio_pdrv_genirq         3666  0 
    uio                     9897  1 uio_pdrv_genirq


    dmesg : affiche les messages du système, informe du travail réalisé

    lsmod 

    Module                  Size  Used by
    snd_bcm2835            21342  0 
    snd_pcm                93100  1 snd_bcm2835
    snd_seq                61097  0 
    snd_seq_device          7209  1 snd_seq
    snd_timer              23007  2 snd_pcm,snd_seq
    snd                    67211  5 snd_bcm2835,snd_timer,snd_pcm,snd_seq,snd_seq_device
    i2c_bcm2708             6200  0 
    spi_bcm2708             6018  0 
    uio_pdrv_genirq         3666  0 
    uio                     9897  1 uio_pdrv_genirq

Résumé de compilation : 
    j'ai appris les commandes insmod et rmmod et lsmod
    commande insmod : le code du module est envoyé directement dans le noyau en cours d'exécution. Il devient actif immédiatement. 
   
    commande rmmod : je pense qu'il retire le module du noyau sur le moment. 
    
    lsmod : affiche la taille du code du module et utilisé par quel utilisateur. 

    Sur le protocole, nous avons ajouté puis retirer le module module.ko 


## Etape 2 : ajout des paramètres au module 

$ sudo insmod ./module.ko btn=18
    [ 4054.334630] Hello World ji_balde !
    [ 4054.334672] btn=18 !


### Question3 : 
execution de la commande : 
$ sudo insmod ./module.ko leds=4,17

Le fichier log contient : 
[ 4342.899830] Hello World !
[ 4342.899873] LED 0 = 4
[ 4342.899885] LED 1 = 17

nous voyons que les valeurs 4 et 17 ont été lus.

## Etape 3 : Création d'un driver qui ne fait rien, mais qui le fait dans le noyau 

lors de la prise en compte des paramètres, la valeur de nbleds est rempli en fonction du nombre de leds définies après "leds=" .

le module led a pour major 246.

essayer de comprendre les commandes : 
    sudo mknod /dev/led0_XY c major 0
    sudo chmod a+rw /dev/led0_XY

mknod : créer un fichier spécial qui représente le matériel 
c : en mode caractère 
major : numéro du majeur 
0 : numéro du mineur 

chmod a : le "a" signifie pour tout le monde 

### Question : Comment savoir que le device a été créé ?
Dans le répertoire /dev , nous voyons le fichier led0_JB que nous venons de le créer. 
`/dev/led0_JB': File exists
`/dev/bp_JB': File exists


### Expliquer chaque étape

$ echo "rien" > /dev/led0_JB
$ dd bs=1 count=1 < /dev/led0_JB
$ dmesg

explication commande 1 : nous écrivons le fichier led0_JB la chaine "rien".

Pour la deuxième étape : 
dd : Data Duplicator -> pour copier des données d'un endroit à un autre de manière bruite


## Etape 4 : accès aux GPIO depuis les fonctions du pilote


Question : Depuis l'extérieur, le bouton poussoir, quand j'appuie sur la valeur, lavaleur va où ? il ne va pas sur la broche ? 

    -> la valeur est stockée dans GPLEV à une adresse précise 
    gpio_regs->gplev[index];

version 1 : 

static ssize_t gpio_read(int pin){
    uint32_t reg = pin / 32;
    uint32_t bit = (pin % 32);

    return gpio_regs->gplev[reg] & (1 << bit) & 0x1;
}

Je pensais que mon code était bon, mais le code retourne presque toujours 0 meme si la LED est allumée.


