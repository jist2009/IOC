#include <linux/module.h>
#include <linux/init.h>
#include <asm/io.h>
#include <mach/platform.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#define NBMAX_LED 32

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JI_BALDE, 2026");
MODULE_DESCRIPTION("Module, aussitot insere, aussitot efface");

static int major_led;
static int major_bp;
static int leds[NBMAX_LED];
static int nbled;
static int pin_bp = 18; 

module_param_array(leds, int, &nbled, 0644);
MODULE_PARM_DESC(leds, "Tableau des numéros de port LED");

module_param(pin_bp, int, 0644);
MODULE_PARM_DESC(pin_bp, "Numéro du port GPIO pour le bouton");


static const int LED0 = 4;

struct gpio_s
{
    uint32_t gpfsel[7];
    uint32_t gpset[3];
    uint32_t gpclr[3];
    uint32_t gplev[3];
    uint32_t gpeds[3];
    uint32_t gpren[3];
    uint32_t gpfen[3];
    uint32_t gphen[3];
    uint32_t gplen[3];
    uint32_t gparen[3];
    uint32_t gpafen[3];
    uint32_t gppud[1];
    uint32_t gppudclk[3];
    uint32_t test[1];
}
volatile *gpio_regs = (struct gpio_s *)__io_address(GPIO_BASE);

static void gpio_fsel(int pin, int fun)
{
    uint32_t reg = pin / 10;
    uint32_t bit = (pin % 10) * 3;
    uint32_t mask = 0b111 << bit;
    gpio_regs->gpfsel[reg] = (gpio_regs->gpfsel[reg] & ~mask) | ((fun << bit) & mask);
}

static void gpio_write(int pin, bool val)
{
    if (val)
        gpio_regs->gpset[pin / 32] = (1 << (pin % 32));
    else
        gpio_regs->gpclr[pin / 32] = (1 << (pin % 32));
}

static ssize_t gpio_read(int pin){
    uint32_t reg = pin / 32;
    uint32_t bit = (pin % 32);

    return (gpio_regs->gplev[reg] & (1 << bit)) != 0;
}



static int 
open_ledbp(struct inode *inode, struct file *file) {
    int i;
    for (i = 0; i < nbled; i++) {
        gpio_fsel(leds[i], 1);
    }
    gpio_fsel(pin_bp, 0);   

    return 0;
}

static ssize_t 
read_ledbp(struct file *file, char *buf, size_t count, loff_t *ppos) {
    char etat;
    printk(KERN_DEBUG "read() de ji_balde\n");

    if (gpio_read(pin_bp)) {
        etat = '1';
    } else {
        etat = '0';
    }

    if (copy_to_user(buf, &etat, 1)) {
        return -EFAULT;
    }

    *ppos += 1;

    return 1; 
}

static ssize_t 
write_ledbp(struct file *file, const char *buf, size_t count, loff_t *ppos) {
    char kbuf;
    int i;

    if (copy_from_user(&kbuf, buf, 1)) {
        return -EFAULT;
    }

    for (i = 0; i < nbled; i++) {
        if (kbuf == '1') {
            gpio_write(leds[i], 1); 
        } else if (kbuf == '0') {
            gpio_write(leds[i], 0); 
        }
    }
    return count;
}

static int 
release_ledbp(struct inode *inode, struct file *file) {
    printk(KERN_DEBUG "close() de ji_balde\n");
    return 0;
}

struct file_operations fops_led =
{
    .open       = open_ledbp,
    .read       = read_ledbp,
    .write      = write_ledbp,
    .release    = release_ledbp 
};

struct file_operations fops_bp =
{
    .open       = open_ledbp,
    .read       = read_ledbp,
    .write      = write_ledbp,
    .release    = release_ledbp 
};



static int __init led_bp_init(void){
    printk(KERN_DEBUG "init ledbp ji_balde !\n");
    major_led = register_chrdev(0, "led0_JB", &fops_led);
    major_bp = register_chrdev(0, "bp_JB", &fops_bp);
    return 0;
}

static void __exit led_bp_exit(void){
    printk(KERN_DEBUG "quitter ledbp ji_balde !\n");
    unregister_chrdev(major_led, "led0_JB");    
    unregister_chrdev(major_bp, "bp_JB"); 
}



module_init(led_bp_init);
module_exit(led_bp_exit);
