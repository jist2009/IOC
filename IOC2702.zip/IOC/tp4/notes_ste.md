# Serveur WEB minimaliste 

## Objectif 
    créer un site web accéder à des capteurs
    changer état des leds. mettre le serveur sur une RaspberryPi 3
    application communiquant avec l'ESP32 avec MQTT
    script CGI 

1. communiquer prog python avec C par FIFO (??)
2. créer server local et le faire communiquer avec le prog C (??)
3. mettre serveur sur RaspberryPi et communiquer en C
4. remplacer prog C par le prog de ctrl des LEDs.

## 1. Communication par FIFO

    pipe : mécanisme de communication entre processus 
    reader.py : le processus lit les données sur le pipe myfifo
    writer.py : le processus écrit des données sur le pipe myfifo
    flush : force l'envoie immédiat des données en attente dans la mémoire tampon 

### Dans quel répertoire est créée la fifo ? 
    Il est crée dans myfifo
### Quelle différence mkfifo et open 
    La fonction mkfifo() : créer le pipe 
    La fonction open() : ouvrir le pipe 
    la différence : on ne créer qu'une seule fois la pipe, on appel x fois pour communiquer (pas sur)

### Pourquoi tester que la fifo existe ?
    éviter l'erreur "FileExistsError" : créer une FIFO alors qu'un fichier avec le même nom existe déjà -> lancer une exception 
    éviter l'écrasement les données ou des permissions 

### à quoi sert flush ?
    Lorsqu'on ajoute une donnée sur le tampon, si le tampon n'est pas rempli -> le tampon attend avant d'envoyer au lecteur 
    La fonction flush va remplir le tamon. 

### Pourquoi ne ferme t on pas le fifo ? 
    le fifo se ferme avec with open(...) ou pipe_in.close() (mais on ne l'utilise pas)
    je ne sais pas 

### Que fait readline ?
    La fonction readline() va lire les données sur le buffer. 

### Expliquez le phénomène (... c'est le open(), mais pourquoi ? ...)

## 2. Création d'un serveur fake 

## 3. Création d'un serveur web