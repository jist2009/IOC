#!/usr/bin/env python
import os, time

s2fName = '/tmp/s2f_jb'
if not os.path.exists(s2fName):
   os.mkfifo(s2fName)
s2f = open(s2fName,'w')

f2sName = '/tmp/f2s_jb'
if not os.path.exists(f2sName):
   os.mkfifo(f2sName)
f2s = open(f2sName,'r')


while True:
   entree_utilisateur = input("Entrez quelque chose : ")
   s2f.write(entree_utilisateur+'\n')
   s2f.flush()
   stri = f2s.readline()
   print(entree_utilisateur)

f2s.close()
s2f.close()
