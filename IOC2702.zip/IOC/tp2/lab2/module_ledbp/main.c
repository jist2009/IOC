#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd_led,fd_bp;
    char led_on = '1';
    char led_off = '0';
    char bouton_etat = '0';
    int i;

    // 1. TEST OPEN
    fd_led = open("/dev/led0_JB", O_RDWR);
    fd_bp = open("/dev/bp_JB", O_RDWR);
    if (fd_led < 0 || fd_bp < 0 ) {
        perror("ERREUR : Impossible d'ouvrir le driver");
        exit(1);
    }

    while (1) {
        // 2. TEST WRITE (Allumer)
        write(fd_led, &led_on, 1);
        printf("LEDs ALLUMÉES... ");
        fflush(stdout);
        
        usleep(500000); 

        // 3. TEST WRITE (Éteindre)
        write(fd_led, &led_off, 1);
        if(led_off == '1'){
            printf("LEDs ÉTEINTES\n");
        }

        
        while(1){
            read(fd_bp, &bouton_etat, 1);
            usleep(100000);
            if (bouton_etat == '1') {
                printf("\nBouton détecté ! Fin de la validation.\n");
            }
        }

        usleep(500000);
    }

    // 5. TEST CLOSE
    close(fd_led);
    close(fd_bp);
    printf("Validation terminée, driver fermé.\n");
    return 0;
}