ssh -p 62222 pi@peri
pi@peri's password: raspberry 

$ scp -P 62222 file.x pi@peri:almada_fomentin
pi@peri's password: raspberry 

j'ai déjà généré la clé, donc ne pas le modifier


la commande scp fait quoi ? 
    scp (Secure Copy protocol) copier des fichiers ou repertoires entre deux machines sur un réseau. <=> comme cp mais entre deux machines.

0ption -static
    L'option "-static" est utilisée par l'éditeur de lien. Elle est importante ici, car la librairie C du compilateur croisé n'est pas tout à fait identique à la librairie C sur la carte RaspberryPi. Ajouter "-static" à la ligne de compilation permet de créer un binaire qui contient en plus les fonctions de la librairie C utilisée par votre programme. Ceci permettra à celui-ci de ne pas essayer d'utiliser des fonctions de la librairie C installée sur la carte qui, sinon, aurait été chargée dynamiquement.
je n'ai pas compris totalement relire plus tard.


## 5. Controle de GPIO en sortie

déjà c'est quoi un GPIO ? les périphériques sont des GPIO -> input/output, interface entre numérique et analogique.

1. Expliquez pourquoi, il pourrait être dangereux de se tromper de broche pour la configuration des GPIO? 
-> se tromper de broche peut modifier des comportements corrects en incorrects causant des effets inhattendu. 

    réponse de gemini : revoir l'electronique (CM0)
    1. conflit électrique, 
        - broche A est configurée en sortie HAUT (elle envoie du 3.3V)
        - broche B est configurée en sortie BAS (elle est reliée à la masse, 0V)
        --> si tu les relies, tu crées un court-circuit direct. => griller le microcontrolleur 
    2. comportement incorrect => peut devenir dangereux. 

2. A quoi correspond l'adresse BCM2835_GPIO_regs_virt ? 

BCM2835 est la puce (SoC) dans les modèles Raspberry, l'adresse permet on écrit sur cette adresse pour 
mmap() -> créer un pont pour connaitre l'adresse physique 

BCM2835_GPIO_regs_virt -> accéder aux registres spécifiques du GPIO 

=> pointeur de la structure 


3. Que représente la structure struct gpio_s ?
    représentation logicielle de l'espace mémoire du périphérique GPIO
    la structure peut controler tous les GPIOS

4.Dans quel espace d'adressage est l'adresse gpio_regs_virt ?
    dans le bus


5. Dans la fonction gpio_fsel(), que contient la variable reg ?
    reg permet de choisir le bon gpio.

6. Dans la fonction gpio_write(), pourquoi écrire à deux adresses différentes en fonction de la valeur val ?
    set = 1 => allumer 
    clr = 1 => éteindre 


7. Dans la fonction gpio_mmap(), à quoi correspondent les flags de open() ?
    les flags "O_RDWR" les droits pour Read et Write , "O_SYNC" synchrone => il permet de faire les modifications (écriture d'un fichier) sur le moment et non le laisser pour plus tard. 


8. Dans la fonction gpio_mmap(), commentez les arguments de mmap().
    ->mmap prend en argument un double pointeur => une pour l'adresse de la structure et l'autre pour son pointeur. si on n'avait pas le pointeur, on modifie l'adresse du pointeur 1e de la structure. 

9. Que fait la fonction delay() ?
    attendre le nombre de milisecondes.

10. Pourquoi doit-on utiliser sudo ? 
    car le code modifie des comportements sur le matériel qui est kernel. 

# 6. Contrôle de plusieurs GPIO en mode "sortie"

Définir une structure : On crée struct blink_args pour regrouper le numéro de la broche (pin) et la période.

Lancer deux threads : On appelle pthread_create deux fois avec des arguments différents.

La fonction de thread : Elle devient générique. Elle récupère ses paramètres, puis entre dans sa boucle de clignotement.